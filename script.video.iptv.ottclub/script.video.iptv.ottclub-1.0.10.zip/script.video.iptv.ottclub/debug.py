from iptvlib import *
from ottclub import Ottclub

if __name__ == "__main__":

    api = Ottclub('spacetv.in', 'KN95FV4RCH', False)

    groups = api.groups

    channel = api.channels["233"]

    program = channel.get_current_program()

    print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

    print "%s" % len(groups)