from ottclub import Ottclub

if __name__ == "__main__":

    api = Ottclub('http://itv.live/p/e44664bfaf8a/ottplayer.m3u', 'XXXXX', False)

    groups = api.groups

    channel = api.channels["316"]

    program = channel.get_current_program()

    print "%s" % len(groups)