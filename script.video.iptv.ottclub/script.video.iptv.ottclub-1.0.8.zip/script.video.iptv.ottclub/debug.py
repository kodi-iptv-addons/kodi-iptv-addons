from ottclub import Ottclub

if __name__ == "__main__":

    api = Ottclub('spacetv.in', 'XXXXX', False)

    groups = api.groups

    print "%s" % len(groups)