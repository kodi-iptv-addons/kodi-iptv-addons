import requests

from iptvlib import *
from ottclub import Ottclub

if __name__ == "__main__":

    #api = Ottclub('spacetv.in', 'KN95FV4RCH', False)
    api = Ottclub('https://itv.live/p/e44664bfaf8a/ottplayerorg.m3u', 'KN95FV4RCH', False)

    groups = api.groups

    channel = api.channels["70"]

    # channel_map = dict()
    # for cid, channel in api.channels.iteritems():
    #     norm = normalize(channel.name)
    #     key = "%s/%s" % (normalize(groups[channel.gid].name), norm)
    #     url1 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/RU/%s/channel.json" % norm
    #     if requests.head(url1).status_code != 200:
    #         channel_map[key] = None
    #     else:
    #         channel_map[key] = "RU/%s" % norm
    #
    # import json
    #
    # print "%s" % json.dumps(channel_map)

    program = channel.get_current_program()

    print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

    print "%s" % len(groups)