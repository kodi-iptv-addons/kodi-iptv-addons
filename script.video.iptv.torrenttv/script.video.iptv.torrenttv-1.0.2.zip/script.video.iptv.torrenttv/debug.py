import traceback

import requests

from iptvlib import *
from torrenttv import Torrenttv

if __name__ == "__main__":



    kwargs = {
        "username": "razdvatris.tibul@gmail.com",
        "password": "WC88iP5UXnmOoZbLdM"
    }

    try:
        api = Torrenttv(adult=False, **kwargs)

        groups = api.groups

        channel = api.channels["7662"]

        channel_map = dict()
        for cid, channel in api.channels.iteritems():
            norm = normalize(channel.name)
            key = "%s/%s" % (normalize(groups[channel.gid].name), norm)
            url1 = "https://kodi-iptv-addons.github.io/EPG/RU/%s/channel.json" % norm
            url2 = "https://kodi-iptv-addons.github.io/EPG/DE/%s/channel.json" % norm
            if requests.head(url1).status_code != 200:
                if requests.head(url2).status_code != 200:
                    channel_map[key] = None
                else:
                    channel_map[key] = "DE/%s" % norm
            else:
                channel_map[key] = "RU/%s" % norm
            print "%s => %s" % (key, channel_map[key])

        import json
        print "%s" % json.dumps(channel_map)

        program = channel.get_current_program()

        print "%s" % api.get_stream_url(channel.cid)
        print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

        programs = channel.programs

        print "%s programs" % len(programs)

    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)