from iptvlib import *
from torrenttv import Torrenttv

if __name__ == "__main__":

    kwargs = {
        "username": "razdvatris.tibul@gmail.com",
        "password": "WC88iP5UXnmOoZbLdM"
    }

    api = Torrenttv(adult=False, **kwargs)

    groups = api.groups

    channel = api.channels["7662"]

    program = channel.get_current_program()

    print "%s" % api.get_stream_url(channel.cid)
    print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

    programs = channel.programs

    print "%s programs" % len(programs)