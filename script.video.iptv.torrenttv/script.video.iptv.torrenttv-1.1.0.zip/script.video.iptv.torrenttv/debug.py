import traceback

import requests

from iptvlib import *
from torrenttv import Torrenttv

if __name__ == "__main__":



    kwargs = {
        "username": "razdvatris.tibul@gmail.com",
        "password": "WC88iP5UXnmOoZbLdM"
    }

    try:
        api = Torrenttv(adult=False, **kwargs)

        groups = api.groups

        channel = api.channels["7662"]

        channel_map = dict()
        for cid, channel in api.channels.iteritems():
            norm = normalize(channel.name)
            key = "%s/%s" % (normalize(groups[channel.gid].name), norm)
            url1 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/RU/%s/channel.json" % norm
            url2 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/DE/%s/channel.json" % norm
            url3 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/UA/%s/channel.json" % norm
            url4 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/BY/%s/channel.json" % norm
            url5 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/KZ/%s/channel.json" % norm
            if requests.head(url1).status_code != 200:
                if requests.head(url2).status_code != 200:
                    if requests.head(url3).status_code != 200:
                        if requests.head(url4).status_code != 200:
                            if requests.head(url5).status_code != 200:
                                channel_map[key] = None
                            else:
                                channel_map[key] = "KZ/%s" % norm
                        else:
                            channel_map[key] = "BY/%s" % norm
                    else:
                        channel_map[key] = "UA/%s" % norm
                else:
                    channel_map[key] = "DE/%s" % norm
            else:
                channel_map[key] = "RU/%s" % norm

        import json

        print "%s" % json.dumps(channel_map)

        program = channel.get_current_program()

        print "%s" % api.get_stream_url(channel.cid)
        print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

        programs = channel.programs

        print "%s programs" % len(programs)

    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)