import json
import re
import urllib
import urllib2
import uuid

from iptvlib import *
from stalker import Stalker

if __name__ == "__main__":

    try:

        api = Stalker(
            mac=':'.join(re.findall('..', '%012x' % uuid.getnode())),
            timezone='Europe/Berlin',
            hostname='s.ottg.tv',
            adult=False,
            timeshift=0,
            username='20161',
            password='613762',
            working_path='./'
        )

        # api = Stalker(
        #     mac=':'.join(re.findall('..', '%012x' % uuid.getnode())),
        #     timezone='Europe/Berlin',
        #     hostname='stb.shara-tv.org',
        #     adult=False,
        #     timeshift=0,
        #     username='xo149231',
        #     password='72635845',
        #     working_path='./'
        # )

        # api = Stalker(
        #     mac=':'.join(re.findall('..', '%012x' % uuid.getnode())),
        #     timezone='Europe/Berlin',
        #     hostname='192.168.178.37',
        #     adult=False,
        #     timeshift=0,
        #     username='1',
        #     password='1',
        #     working_path='./'
        # )

        #api.login()

        api.get_modules()

        groups = api.groups

        channel = api.channels["ch003"]

        programs = channel.programs

        print "%s programs" % len(programs)

    except Exception, ex:

        print "Exception: %s" % str(ex)
