import traceback

import xbmc
from kartina import Kartina
from xbmc import log

if __name__ == "__main__":

    try:
        api = Kartina(
            hostname='iptv.kartina.tv',
            adult=False,
            username='12828382',
            password='374308',
            working_path='./'
        )

        groups = api.groups

    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)