import traceback

import requests

import xbmc
from iptvlib import normalize
from kartina import Kartina
from xbmc import log

if __name__ == "__main__":

    try:
        api = Kartina(
            hostname='iptv.kartina.tv',
            adult=False,
            username='12940547',
            password='446367',
            working_path='./'
        )

        groups = api.groups

        # channel_map = dict()
        # for cid, channel in api.channels.iteritems():
        #     norm = normalize(channel.name)
        #     key = "%s/%s" % (normalize(groups[channel.gid].name), norm)
        #     url1 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/RU/%s/channel.json" % norm
        #     url2 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/DE/%s/channel.json" % norm
        #     url3 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/UA/%s/channel.json" % norm
        #     url4 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/BY/%s/channel.json" % norm
        #     url5 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/KZ/%s/channel.json" % norm
        #     if requests.head(url1).status_code != 200:
        #         if requests.head(url2).status_code != 200:
        #             if requests.head(url3).status_code != 200:
        #                 if requests.head(url4).status_code != 200:
        #                     if requests.head(url5).status_code != 200:
        #                         channel_map[key] = None
        #                     else:
        #                         channel_map[key] = "KZ/%s" % norm
        #                 else:
        #                     channel_map[key] = "BY/%s" % norm
        #             else:
        #                 channel_map[key] = "UA/%s" % norm
        #         else:
        #             channel_map[key] = "DE/%s" % norm
        #     else:
        #         channel_map[key] = "RU/%s" % norm
        #
        # import json
        # print "%s" % json.dumps(channel_map)

        channel = api.channels['785']

        program = channel.get_current_program()


    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)