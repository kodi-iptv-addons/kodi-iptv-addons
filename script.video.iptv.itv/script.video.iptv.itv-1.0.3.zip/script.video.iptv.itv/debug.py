from iptvlib import *
from itv import Itv

if __name__ == "__main__":

    api = Itv("api.itv.live", "e44664bfaf8a1", False)

    groups = api.groups

    channel = api.channels["ch238"]

    program = channel.get_current_program()

    print "%s" % api.get_stream_url(channel.cid)
    print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

    programs = channel.programs

    print "%s programs" % len(programs)