import requests

from iptvlib import *
from itv import Itv

if __name__ == "__main__":

    try:

        api = Itv(hostname="api.itv.live", key="e44664bfaf8a", adult=False)
        # api = Itv(hostname="api.itv.live", key="46CE02062C7C", adult=False, sort_channels=False)

        api.login()

        groups = api.groups

        channel = api.channels["ch212"]

        # channel_map = dict()
        # for cid, channel in api.channels.iteritems():
        #     norm = normalize(channel.name)
        #     key = "%s/%s" % (normalize(groups[channel.gid].name), norm)
        #     url1 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/RU/%s/channel.json" % norm
        #     url2 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/DE/%s/channel.json" % norm
        #     url3 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/UA/%s/channel.json" % norm
        #     url4 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/BY/%s/channel.json" % norm
        #     url5 = "https://raw.githubusercontent.com/kodi-iptv-addons/EPG/master/KZ/%s/channel.json" % norm
        #     if requests.head(url1).status_code != 200:
        #         if requests.head(url2).status_code != 200:
        #             if requests.head(url3).status_code != 200:
        #                 if requests.head(url4).status_code != 200:
        #                     if requests.head(url5).status_code != 200:
        #                         channel_map[key] = None
        #                     else:
        #                         channel_map[key] = "KZ/%s" % norm
        #                 else:
        #                     channel_map[key] = "BY/%s" % norm
        #             else:
        #                 channel_map[key] = "UA/%s" % norm
        #         else:
        #             channel_map[key] = "DE/%s" % norm
        #     else:
        #         channel_map[key] = "RU/%s" % norm
        #
        # import json
        # print "%s" % json.dumps(channel_map)

        # epg = api.get_epg("ch212")

        program = channel.get_current_program()

        print "%s" % api.get_stream_url(channel.cid)
        print "%s" % api.get_stream_url(channel.cid, 1542652390)

        programs = channel.programs

        print "%s programs" % len(programs)
    except Exception, ex:

        print "Exception: %s" % str(ex)