from iptvlib import *
from itv import Itv

if __name__ == "__main__":

    try:

        api = Itv("api.itv.live", "e44664bfaf8a", False)
        #api = Itv("api.itv.live", "46CE02062C7C", False)

        api.login()

        groups = api.groups

        channel = api.channels["ch212"]

        program = channel.get_current_program()

        print "%s" % api.get_stream_url(channel.cid)
        print "%s" % api.get_stream_url(channel.cid, 1542652390)

        programs = channel.programs

        print "%s programs" % len(programs)
    except Exception, ex:

        print "Exception: %s" % str(ex)