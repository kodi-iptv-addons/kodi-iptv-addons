import traceback

import xbmc
from iptvlib import time_now, HALFHOUR
from ottplayer import Ottplayer
from xbmc import log

if __name__ == "__main__":

    try:
        api = Ottplayer('api.ottplayer.es:9000', False, username='dmitri.vinogradov@gmail.com', password='k1tchens69')

        api.login()

        groups = api.groups

        channels = api.channels

        channel = channels["44095975-6"]

        program = channel.get_current_program()

        print "%s" % api.get_stream_url(channel.cid, int(time_now() - HALFHOUR))

        print "%s" % len(groups)
    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)