import traceback

import xbmc
from ottplayer import Ottplayer
from xbmc import log

if __name__ == "__main__":

    try:
        api = Ottplayer('api.ottplayer.es:9000', False, username='dmitri.vinogradov@gmail.com', password='k1tchens69')

        api.login()

        groups = api.groups

        channels = api.channels

        print "%s" % len(groups)
    except Exception, ex:
        log("Exception %s: message=%s" % (type(ex), ex.message))
        log(traceback.format_exc(), xbmc.LOGDEBUG)