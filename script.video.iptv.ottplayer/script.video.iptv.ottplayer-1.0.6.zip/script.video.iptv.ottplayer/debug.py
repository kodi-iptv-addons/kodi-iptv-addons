from ottplayer import Ottplayer

if __name__ == "__main__":

    api = Ottplayer('api.ottplayer.es:9000', False, username='dmitri.vinogradov@gmail.com', password='k1tchens69')

    groups = api.groups

    channels = api.channels

    print "%s" % len(groups)